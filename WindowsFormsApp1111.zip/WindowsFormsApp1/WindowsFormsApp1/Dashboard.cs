﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }


        private void btnAddroom_Click(object sender, EventArgs e)
        {
            MovingPanel.Left = btnAddroom.Left + 20;

        }

        private void btnCustomerregistration_Click(object sender, EventArgs e)
        {
            MovingPanel.Left = btnCustomerregistration.Left+30;
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            MovingPanel.Left = btnCheckout.Left + 18;

        }

        private void btnCustomerdetails_Click(object sender, EventArgs e)
        {
            MovingPanel.Left = btnCustomerdetails.Left + 20;

        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            MovingPanel.Left = btnEmployee.Left + 20;

        }

        private void MovingPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void uC_AddRoom1_Load(object sender, EventArgs e)
        {

        }
    }
}
